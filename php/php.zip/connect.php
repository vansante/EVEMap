<?php

$connection = mysql_connect('localhost', 'root', '');
mysql_select_db('dbo');

set_time_limit(100000);

?>